# Cómo descargar las miniaturas (113 imágenes, 30 casos)

Contenido de esta carpeta:
- `miniaturas_enlaces.csv`: una fila por vídeo (carpeta del caso, caso, canal, título, vistas, enlaces).
- `enlaces.txt`: solo las 113 URLs (maxresdefault.jpg), una por línea.
- `bajar_miniaturas.py`: el script que las descarga y las ordena por caso.

## Opción A: en tu ordenador (la más fácil)
1. Descomprime la carpeta.
2. Abre una terminal dentro de la carpeta y ejecuta:  `python3 bajar_miniaturas.py`
3. Resultado: `miniaturas/<carpeta_del_caso>/NN_mismocaso_VISTASvistas_canal_videoId.jpg`.
   Si una miniatura de máxima calidad no existe, usa la de calidad media (`hqdefault`). Si algún vídeo falla, lo lista al final.
Necesita Python 3 e internet. No hay que instalar nada.

## Opción B: solo con enlaces
`wget -i enlaces.txt -P miniaturas` (o `curl -O` por línea). No las ordena por caso; el CSV te dice a qué caso pertenece cada `videoId`.

## Opción C: pasárselo a otra IA con acceso a internet
Adjunta este .zip (o el CSV y el script) y pega este mensaje:

> Descomprime el zip. Ejecuta `python3 bajar_miniaturas.py` en la carpeta (requiere acceso a i.ytimg.com). Si no puedes ejecutar código, abre cada URL de `miniaturas_enlaces.csv` (columna `url_maxres`, o `url_hq` si da 404) y guarda la imagen en `miniaturas/<carpeta>/` con el nombre `NN_videoId.jpg`. Al terminar, devuélveme un .zip con la carpeta `miniaturas/` y dime cuántas bajaste y cuáles fallaron. No modifiques las imágenes.

Si la otra IA tiene el dominio bloqueado, necesita permitir `i.ytimg.com` e `img.youtube.com`.

## Aviso de uso
Son miniaturas de vídeos de la competencia, para estudiar su estilo. No las reutilices en tus vídeos: tienen derechos de autor, y muchas llevan fotos de víctimas reales. Para las tuyas, usa fotos reales de archivo con crédito o imágenes no identificables, y nunca una cara generada con IA presentada como la víctima o el sospechoso.
