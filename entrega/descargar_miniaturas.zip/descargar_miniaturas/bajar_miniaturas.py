#!/usr/bin/env python3
"""Descarga las miniaturas de miniaturas_enlaces.csv en miniaturas/<carpeta_del_caso>/.
Solo usa la libreria estandar de Python 3. Uso:  python3 bajar_miniaturas.py
Si maxresdefault.jpg no existe (404), usa hqdefault.jpg."""
import csv, os, re, sys, time, urllib.request, urllib.error
AQUI = os.path.dirname(os.path.abspath(__file__))
SALIDA = os.path.join(AQUI, "miniaturas")
UA = {"User-Agent": "Mozilla/5.0"}

def bajar(url):
    req = urllib.request.Request(url, headers=UA)
    with urllib.request.urlopen(req, timeout=30) as r:
        datos = r.read()
    # YouTube devuelve una imagen gris de ~1 KB si la miniatura no existe
    return datos if len(datos) > 2000 else None

def limpio(s, n=60):
    return re.sub(r"[^A-Za-z0-9]+", "_", s or "").strip("_")[:n]

ok = fallos = 0
with open(os.path.join(AQUI, "miniaturas_enlaces.csv"), newline="", encoding="utf-8-sig") as fh:
    for f in csv.DictReader(fh):
        carpeta = os.path.join(SALIDA, f["carpeta"])
        os.makedirs(carpeta, exist_ok=True)
        nombre = f'{int(f["n"]):02d}_{f["coincidencia"].replace(" ", "")}_{f["vistas"]}vistas_{limpio(f["canal"],25)}_{f["videoId"]}.jpg'
        destino = os.path.join(carpeta, nombre)
        if os.path.exists(destino):
            ok += 1; continue
        datos = None
        for clave in ("url_maxres", "url_hq"):
            try:
                datos = bajar(f[clave])
            except (urllib.error.URLError, TimeoutError) as e:
                print("  aviso:", f["videoId"], clave, e)
            if datos: break
        if datos:
            open(destino, "wb").write(datos); ok += 1
            print("OK ", f["carpeta"][:2], nombre)
        else:
            fallos += 1; print("FALLO", f["videoId"], f["titulo"])
        time.sleep(0.2)
print(f"\nListo: {ok} descargadas, {fallos} fallos. Carpeta: {SALIDA}")
sys.exit(1 if fallos else 0)
